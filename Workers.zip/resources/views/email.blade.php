<!DOCTYPE html>
<html>
<body>
<h1>Verification Code</h1>
<p>Hello {{$name}}</p>
<p>Verification Code is </p>
<a href="{{$link}}">{{$link}}</a>
</body>
</html>
