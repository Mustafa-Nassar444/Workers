<?php echo e($slot); ?>

<?php /**PATH F:\FCI\My-GitHub\Workers\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>