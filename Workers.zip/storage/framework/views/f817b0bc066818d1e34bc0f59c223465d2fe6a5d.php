<!DOCTYPE html>
<html>
<body>
<h1>Verification Code</h1>
<p>Hello <?php echo e($name); ?></p>
<a href="<?php echo e($link); ?>">Verification Code is <?php echo e($link); ?></a>
</body>
</html>
<?php /**PATH F:\FCI\My-GitHub\Workers\resources\views/email.blade.php ENDPATH**/ ?>